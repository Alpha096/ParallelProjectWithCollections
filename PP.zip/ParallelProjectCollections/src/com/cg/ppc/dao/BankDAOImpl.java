package com.cg.ppc.dao;

import java.util.HashMap;
import java.util.Map;
import com.cg.ppc.dto.Customer;
import com.cg.ppc.exception.BankAccountException;

public class BankDAOImpl implements BankDAO{
	
	Map<String,Customer> custMap;
	
	public BankDAOImpl(){
	custMap = new HashMap<>();
	custMap.put("9010210131", new Customer("9010210131", "Vaishali", 20, 5000));
	custMap.put("9823920123", new Customer("9823920123", "Megha", 45, 6000));
	custMap.put("9932012345", new Customer("9932012345", "Vikas", 63, 10000));
	}
	
	@Override
	public void createAccount(Customer customer) {
		custMap.put(customer.getMobileNo(),customer);
		
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		Customer customer = custMap.get(mobileNo);
		if(customer != null){
			double updateAmount = customer.getInitialBalance();
			updateAmount += amount;
			String name = customer.getName();
			String newMobileNo = customer.getMobileNo();
			float age = customer.getAge();
			
			customer.setAge(age);
			customer.setInitialBalance(updateAmount);
			customer.setName(name);
			customer.setMobileNo(newMobileNo);
			
			custMap.put(newMobileNo, customer);
			System.out.println("Amount deposited! New balance: "+ customer.getInitialBalance());
		}
	}

	@Override
	public void withdraw(String mobileNo, double withdrawAmount) {
		Customer customer = custMap.get(mobileNo);
		if(customer != null){
			double amount = customer.getInitialBalance();	
			
			String name = customer.getName();
			String newMobileNo = customer.getMobileNo();
			float age = customer.getAge();
			
			if(amount - withdrawAmount > 500){
				amount -= withdrawAmount;
				customer.setAge(age);
				customer.setInitialBalance(amount);
				customer.setName(name);
				customer.setMobileNo(newMobileNo);
				
				custMap.put(newMobileNo, customer);
				System.out.println("Amount withdrawn! New balance: "+ customer.getInitialBalance());
			}
			else{
				System.out.println("Cannot withdraw!");
			}
			}
		else{
			System.out.println("Mobile number not found");
		}
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		Customer custCheckBalance = custMap.get(mobileNo);
		double amount = custCheckBalance.getInitialBalance();
		return amount;
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		String name, newMobileNo;
		float age;
		
		Customer custSender =  custMap.get(sender);
		Customer custReciever = custMap.get(reciever);
		
		double recieverAmount = custReciever.getInitialBalance();
		double senderAmount = custSender.getInitialBalance();
		if(senderAmount - amount > 500){
			recieverAmount += amount;
			senderAmount -= amount;
			name = custSender.getName();
			newMobileNo = custSender.getMobileNo();
			age = custSender.getAge();
		
			
			custSender.setAge(age);
			custSender.setInitialBalance(senderAmount);
			custSender.setMobileNo(newMobileNo);
			custSender.setName(name);
			
			custMap.put(newMobileNo, custSender);
			
			name = custReciever.getName();
			newMobileNo = custReciever.getMobileNo();
			age = custReciever.getAge();
			
			
			custReciever.setAge(age);
			custReciever.setInitialBalance(recieverAmount);
			custReciever.setMobileNo(newMobileNo);
			custReciever.setName(name);
			
			custMap.put(newMobileNo, custReciever);	
			System.out.println("Fund Transferred");
		}
		else{
			System.out.println("Cannot transfer!");
		}
		
	}

	@Override
	public boolean validateAccount(String mobileNo) throws BankAccountException {
		Customer customer = custMap.get(mobileNo);
		if(customer == null)
			return false;
		return true;
	}

}
